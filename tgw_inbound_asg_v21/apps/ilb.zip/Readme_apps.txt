# pan_nlb_v1
This is the V1 (CFT) template to deploy an NLB architecture to AWS.
