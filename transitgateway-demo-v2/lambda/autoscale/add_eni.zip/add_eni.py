"""
/*****************************************************************************
 * Copyright (c) 2016, Palo Alto Networks. All rights reserved.              *
 *                                                                           *
 * This Software is the property of Palo Alto Networks. The Software and all *
 * accompanying documentation are copyrighted.                               *
 *****************************************************************************/

Copyright 2016 Palo Alto Networks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from __future__ import print_function
import boto3
import botocore
import json
import logging
import time
import uuid
import sys
import ssl
import os

sys.path.append('lib/')
# import asglib as lib

# mgmt = ""
# untrust = ""
# trust = ""
# sgm = ""
# sgu = ""
# sgt = ""
# sgv = ""

ScalingParameter = ""
Namespace = ""
asg_name = ""
SubnetIDNATGW = ""

# SubnetIDLambda=""
# elb_name=""
Arn = ""
debug = ""

asg = boto3.client('autoscaling')
ec2 = boto3.resource('ec2')
ec2_client = ec2.meta.client
lambda_client = boto3.client('lambda')
iam = boto3.client('iam')
events_client = boto3.client('events')
cloudwatch = boto3.client('cloudwatch')


valid_panfw_productcode_byol = {
    "6njl1pau431dv1qxipg63mvah": "VMLIC_BYOL",
    # AWS IC product codes
    "3bgub3avj7bew2l8odml3cxdx": "VMLIC_IC_BYOL",
}


def get_lambda_cloud_watch_func_name(stackname, instanceId):
    """

    :param stackname:
    :param instanceId:
    :return:
    """
    name = asg_name + '-cwm-' + str(instanceId)
    return name[-63:len(name)]


def get_event_rule_name(stackname, instanceId):
    """

    :param stackname:
    :param instanceId:
    :return:
    """
    name = stackname + '-cw-event-rule-' + str(instanceId)
    return name[-63:len(name)]


def get_statement_id(stackname, instanceId):
    """

    :param stackname:
    :param instanceId:
    :return:
    """
    name = stackname + '-cw-statementid-' + str(instanceId)
    return name[-63:len(name)]


def get_target_id_name(stackname, instanceId):
    """

    :param stackname:
    :param instanceId:
    :return:
    """
    name = stackname + '-lmda-target-id' + str(instanceId)
    return name[-63:len(name)]


def random_string(string_length=10):
    """

    :param string_length:
    :return:
    """
    random = str(uuid.uuid4())
    random = random.replace("-", "")
    return random[0:string_length]


def remove_eni_in_subnet(subnet):
    """

    :param subnet:
    :return:
    """
    response = ec2_client.describe_network_interfaces(Filters=[{'Name': "subnet-id", 'Values': [str(subnet)]}])
    for i in response['NetworkInterfaces']:
        if i['Status'] == "available":
            logger.info('Removing Network Interfaces in Available state for subnetid : ' + subnet)
            eniId = i['NetworkInterfaceId']
            logger.info(
                'Removing Eni ID: ' + eniId + ' Desc: ' + i['Description'] + ' IP: ' + i['PrivateIpAddress'] + ' AZ: ' +
                i['AvailabilityZone'])
            try:
                ec2_client.delete_network_interface(NetworkInterfaceId=eniId)
            except Exception as e:
                logger.warning("[delete Eni for subnet]: {}".format(e))

    return


def remove_eni(message):
    """

    :param message:
    :return:
    """
    instanceId = message['EC2InstanceId']
    logger.info('Removing Network Interfaces for instanceId: ' + instanceId)

    # Detach all the ENIs first
    response = ec2_client.describe_network_interfaces(
        Filters=[{'Name': "attachment.instance-id", 'Values': [str(instanceId)]}])
    cnt = 0
    eni_ids = []
    for i in response['NetworkInterfaces']:
        eniId = i['NetworkInterfaceId']
        Attachment = i['Attachment']
        aId = Attachment['AttachmentId']
        logger.info(
            'Detaching Eni ID: ' + eniId + ' Desc: ' + i['Description'] + ' IP: ' + i['PrivateIpAddress'] + ' AZ: ' + i[
                'AvailabilityZone'])
        logger.info('Detaching Attachment ID: ' + aId + ' DeviceIndex: ' + str(Attachment['DeviceIndex']))
        if Attachment['DeviceIndex'] != 0:
            try:
                ec2_client.detach_network_interface(AttachmentId=aId)
                cnt = cnt + 1
                eni_ids.append(str(eniId))
            except Exception as e:
                logger.warning("[detach Eni]: {}".format(e))
                try:
                    ec2_client.delete_network_interface(NetworkInterfaceId=eniId)
                except Exception as e:
                    logger.warning("[delete Eni]: {}".format(e))

    if cnt == 0:
        logger.warning('No more ENIs for delete. Strange though')
        return

    logger.info('Delete ENIs PANW InstanceID: ' + str(instanceId) + ' ENI cnt: ' + str(cnt))
    logger.info('Delete ENIs: ' + str(eni_ids))

    # Now delete ENIs if they are in 'available' state
    fcnt = 0
    for timeout in range(0, 25):
        if fcnt == cnt:
            logger.info('Finally Done with deleting all ENIs')
            return

        response = ec2_client.describe_network_interfaces(
            NetworkInterfaceIds=eni_ids,
            Filters=[{'Name': 'status', 'Values': ['available']}])

        for i in response['NetworkInterfaces']:
            id = i['NetworkInterfaceId']
            fcnt = fcnt + 1
            try:
                ec2_client.delete_network_interface(NetworkInterfaceId=id)
            except Exception as e:
                logger.error("[delete Eni after detach]: {}".format(e))

        time.sleep(5)

    response = ec2_client.describe_network_interfaces(NetworkInterfaceIds=eni_ids)
    for i in response['NetworkInterfaces']:
        logger.error('Timed out waiting for detach ENI. Final cnt: ' + str(fcnt) + ' vs ' + str(cnt))
        logger.error(i)

    logger.error('Return from remove_eni due to detach issue')
    return


def count_eni(msg, instanceId):
    """

    :param msg:
    :param instanceId:
    :return:
    """
    response = ec2_client.describe_network_interfaces(
        Filters=[{'Name': "attachment.instance-id", 'Values': [str(instanceId)]}])
    # logger.info(response)
    cnt = 0
    for i in response['NetworkInterfaces']:
        cnt = cnt + 1
    logger.info(msg + ' PANW InstanceID: ' + str(instanceId) + ' ENI cnt: ' + str(cnt))
    return cnt


def associateAddress(AllocId, nifId):
    """

    :param AllocId:
    :param nifId:
    :return bool:
    """
    logger.info('EIP Associate AllocId: ' + str(AllocId) + ' ENI Id: ' + str(nifId))
    try:
        ec2_client.associate_address(AllocationId=AllocId, NetworkInterfaceId=nifId)
    except Exception as e:
        logger.error("[associateAddress failed]: {}".format(e))
        return False
    else:
        logger.info("Associated EIP")
        return True


def getUnassociatedAddress(eip_list):
    """

    :param eip_list:
    :return:
    """
    address =""
    fail = {'PublicIp': 'None', 'Domain': 'vpc', 'AllocationId': 'None'}
    logger.info("Trying to find and eip that is not associated")
    logger.info(eip_list)
    for eip_iter in eip_list:
        # is the public ip address associated with an instance id, if so don't use it
        logger.info('eip_iter is as follows:')
        logger.info(eip_iter)
        if "InstanceId" not in eip_iter:
            if "AllocationId" not in eip_iter:
                address = eip_iter['PublicIp']
                if address:
                    return eip_iter
    return None


def get_eip(untrust_eniId, untrust_instanceId):
    """

    :param untrust_eniId:
    :param untrust_instanceId:
    :return:
    """
    fail = {'PublicIp': 'None', 'Domain': 'vpc', 'AllocationId': 'None'}
    dict = ec2_client.describe_addresses()
    logger.info(dict)

    found = False
    for i in dict['Addresses']:
        found = True
        break

    if found == False:
        try:
            response = ec2_client.allocate_address(Domain='vpc')
            return response
        except Exception as e:
            logger.error("[alloate_eip_address failed]: {}".format(e))
            return None

    response = getUnassociatedAddress(dict)
    if response is None:
        try:
            response = ec2_client.allocate_address(Domain='vpc')
            return response
        except Exception as e:
            logger.error("[alloate_eip_address failed]: {}".format(e))
            return None
    return response


def get_ssl_context():
    """
    Create default ssl context
    """
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ctx.options = ssl.PROTOCOL_TLSv1_2
    return ctx


# def get_device_serial_no(gcontext, instanceId, fwMgmtIp, fwApiKey):
#     """
#     Retrieve the serial number from the FW.
#
#     :param gcontext: ssl context
#     :param instanceId: instance Id
#     :param fwMgmtIp: The IP address of the FW
#     :param fwApiKey: Api key of the FW
#
#     :return: The serial number of the FW
#     :rtype: str
#     """
#
#     serial_no = None
#     if fwMgmtIp is None:
#         logger.error('Firewall IP could not be found. Can not interact with the device')
#         return None
#
#     logger.info('Retrieve the serial number from FW {} with IP: {}'.format(instanceId, fwMgmtIp))
#     fw_cmd = "https://" + fwMgmtIp + "/api/?type=op&key=" + fwApiKey + "&cmd=<show><system><info/></system></show>"
#     try:
#         response = runCommand(gcontext, fw_cmd, fwMgmtIp, fwApiKey)
#         if response is None:
#             pan_print('CFG_FW_GET_SERIAL_NO: Failed to run command: ' + fw_cmd)
#             return None
#     except Exception as e:
#         pan_print("[CFG_FW_GET_SERIAL_NO]: {}".format(e))
#         return None
#
#     resp = et.fromstring(response)
#     serial_info = resp.findall(".//serial")
#     for info in serial_info:
#         serial_no = info.text
#
#     if not serial_no:
#         logger.error("Unable to retrieve the serial number from device: {} with IP: {}".format(instanceId, fwMgmtIp))
#
#     return serial_no


# def handle_instance_termination(fwApiKey, instanceId, fwMgmtIp, PIP):
#     """
#     Execute the sequence to deactivate the Firewall in the case of BYOL.
#     :param fwApiKey:
#     :param instanceId:
#     :param fwMgmtIp:
#     :param PIP: Panorama IP
#     :return bool:
#     """
#
#     fwcontext = get_ssl_context()
#
#     serial_no = get_device_serial_no(fwcontext, instanceId, fwMgmtIp, fwApiKey)
#     if not serial_no:
#         logger.error('Unable to retrieve the serial no for device with IP: {}'.format(fwMgmtIp))
#         return False
#
#     logger.info('The serial number retrieved from device with IP: {} is {}'.format(fwMgmtIp, serial_no))
#
#     try:
#         instance_info = ec2_client.describe_instance_attribute(
#             Attribute='productCodes',
#             InstanceId=instanceId,
#         )
#     except Exception as e:
#         logger.info("Exception occured while retrieving instance ID information: {}".format(e))
#
#     logger.info('describe_instance_attribute:response: {}'.format(instance_info))
#     valid_byol = False
#     for code in instance_info['ProductCodes']:
#         product_code_id = code.get("ProductCodeId", None)
#         if product_code_id in valid_panfw_productcode_byol.keys():
#             valid_byol = True
#             break
#
#     if valid_byol:
#         for retry in range(1, 10):
#             logger.info('Identified the fw license as BYOL. The fw will be de-licensed now.')
#             try:
#                 pass
#                 ## FIXME
#                 ret = "ok"
#                 #ret = lib.deactivate_fw_license_panorama(PIP, KeyPANWPanorama, serial_no)
#             except Exception as e:
#                 logger.exception(
#                     "Exception occurred during deactivate license for device: {} with IP: {}. Error:  {}".format(
#                         instanceId, fwMgmtIp, e))
#                 break
#             else:
#                 if not ret:
#                     logger.error(
#                         'Failed to deactivate the license for device: {} with IP: {}'.format(instanceId, fwMgmtIp))
#                 else:
#                     logger.info(
#                         'Successfully deactivated license for device: {} with IP: {}'.format(instanceId, fwMgmtIp))
#                     break
#                 time.sleep(30)
#     else:
#         logger.info("This firewall device does not have a BYOL license.")
#     try:
#         logger.info('Attempting to shutdown the fw device: {} with IP: {}'.format(instanceId, fwMgmtIp))
#         ## FIXME
#         #ret = lib.shutdown_fw_device(fwcontext, instanceId, fwMgmtIp, fwApiKey)
#         #if not ret:
#         #    logger.error('Error encountered while shutting down the firewall device: {} with IP: {}'.format(instanceId,
#         #                                                                                                    fwMgmtIp))
#         #    return False
#         logger.info("Firewall device: {} with IP: {} successfully shutdown.".format(instanceId, fwMgmtIp))
#     except Exception as e:
#         logger.exception(
#             'Exception shutting down firewall device: {} with IP:{} Error: {}'.format(instanceId, fwMgmtIp, e))
#
#     logger.info('Termination sequence completed.')
#     return True


def check_belongsto_az(list_subnet, az):
    """
    :param list_subnet
    :param az
    :return: chosensubnet/None
    """
    list_len = len(list_subnet)
    for i in range(list_len):
        response = ec2_client.describe_subnets(SubnetIds=[list_subnet[i]])
        logger.info('Retrived response for subnet data{}'.format(response))
        for r in response['Subnets']:
            subnetaz = r['AvailabilityZone']
            if (subnetaz == az):
                chosensubnet = r['SubnetId']
                #                logger.info ("Found the required subnet for this instance :" +chosensubnet)
                return chosensubnet
    return None


def abandon(context, asg_message):
    """
    Method to send a response to the
    auto scale life cycle action.

    :param context:
    :param asg_message:
    :return:
    """
    result = "ABANDON"

    # call autoscaling
    try:
        asg.complete_lifecycle_action(
            AutoScalingGroupName=asg_message['AutoScalingGroupName'],
            LifecycleHookName=asg_message['LifecycleHookName'],
            LifecycleActionToken=asg_message['LifecycleActionToken'],
            LifecycleActionResult=result)
    except Exception as e:
        logger.error("[complete_lifecycle_action]: {}".format(e))


def done(success, context, asg_message):
    """
    Method to send a successful response to an
    ASG lifecycle action.

    :param success:
    :param context:
    :param asg_message:
    :return:
    """
    result = "CONTINUE"

    # call autoscaling
    try:
        asg.complete_lifecycle_action(
            AutoScalingGroupName=asg_message['AutoScalingGroupName'],
            LifecycleHookName=asg_message['LifecycleHookName'],
            LifecycleActionToken=asg_message['LifecycleActionToken'],
            LifecycleActionResult=result)
    except Exception as e:
        logger.error("[complete_lifecycle_action]: {}".format(e))
        return False

    return True


# Create a network interface, pass the Interface ID to callback
def createEni(subnetId, securityGroups, index):
    """
    Method to create and Elastic Network Interface
    :param subnetId:
    :param securityGroups:
    :param index:
    :return:
    """
    # global nif
    # global eniId


    desc = asg_name + '-eth' + str(index)
    logger.info('Creating ENI for Subnet: ' + subnetId)
    logger.info('Creating ENI for SG: ' + securityGroups)
    try:
        nif = ec2.create_network_interface(SubnetId=subnetId, Groups=[securityGroups], Description=desc)
    except botocore.exceptions.ClientError as error:
        logger.info("ERROR: ENI creation failed.\n")
        logger.info(error)
        return 'false'
    else:
        logger.info("INFO: ENI Created.\n")
        try:
            nif.modify_attribute(SourceDestCheck={'Value': False})
            nif.reload()
            response = nif.describe_attribute(Attribute='description')
            eniId = response['NetworkInterfaceId']
            logger.info('Eni-id for newly created ENI is: ' + str(eniId))
        except Exception as e:
            logger.error("[createEni modify attr, reload failed]: {}".format(e))
            logger.error('Deleting previously created ENI')
            logger.error(nif)
            logger.error('Nif id is: ' + str(nif.id))
            removeEni(nif.id)
            return 'false'

        return eniId, 'true'


def removeEni(eniId1):
    """
    Method to disassociate an ENI from an instance.
    :param eniId1:
    :return:
    """
    try:
        ec2_client.delete_network_interface(NetworkInterfaceId=eniId1)
    except Exception as e:
        logger.error("[removeEni]: {}".format(e))

    return


def waitEniReady(eniId):
    """
    Method to check if an ENI is ready
    :param eniId:
    :return:
    """
    try:
        waiter = ec2_client.get_waiter('network_interface_available')
        waiter.wait(NetworkInterfaceIds=[eniId], Filters=[{'Name': 'status', 'Values': ['available']}])
    except botocore.exceptions.ClientError:
        logger.info("ERROR: ENI failed to reach desired state\n")
        return 'false'
    else:
        return 'true'


def attachEni(ec2Id, eniId, index):
    """
    Method to attach and ENI to an instance
    :param ec2Id:
    :param eniId:
    :param index:
    :return:
    """
    try:
        response = ec2_client.attach_network_interface(NetworkInterfaceId=eniId, InstanceId=ec2Id, DeviceIndex=index)
        aid = response['AttachmentId']
        ec2_client.modify_network_interface_attribute(NetworkInterfaceId=eniId,
                                                      Attachment={'AttachmentId': aid, 'DeleteOnTermination': True})
    except Exception as e:
        logger.error("[attach/modify Eni]: {}".format(e))
        return 'false'

    else:
        logger.info('INFO: ENI attached EC2 instance for index: ' + str(index))
        return 'true'


def retrieve_fw_ip(instance_id):
    """
    Retrieve the IP of the Instance

    :param instance_id: The id of the instance
    :type instance_id: str
    """

    eni_response = ec2_client.describe_network_interfaces(
        Filters=[{'Name': "attachment.instance-id", 'Values': [instance_id]},
                 {'Name': "attachment.device-index", 'Values': ["1"]}])

    logger.info("Describe network interfaces response: {}".format(eni_response))

    eniId = ""
    for eni in eni_response['NetworkInterfaces']:
        eniId = eni['NetworkInterfaceId']

    if eniId == "":
        logger.error('Mgmt ENI ID not found for instance: ' + instance_id)
        return False

    logger.info('Eni ID (eth1) for instance : ' + instance_id + ' is: ' + eniId)
    try:
        response = ec2_client.describe_network_interfaces(NetworkInterfaceIds=[eniId])
    except Exception as e:
        logger.error("[Describe network interfaces failed while retrieving fw ip]: {}".format(e))
        return False
"""
/*****************************************************************************
 * Copyright (c) 2016, Palo Alto Networks. All rights reserved.              *
 *                                                                           *
 * This Software is the property of Palo Alto Networks. The Software and all *
 * accompanying documentation are copyrighted.                               *
 *****************************************************************************/

Copyright 2016 Palo Alto Networks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

def allocateEip():
    try:
        eip = ec2_client.allocate_address(Domain='vpc')
    except Exception as e:
        logger.info("[ERROR]: Unable to allocate elastic IP {}".format(e))
        return 'false'
    else:
        #Associate eip with Instance ID
        logger.info("[INFO]: Allocated elastic IP\n")
        return eip

def allocate_and_attach_eip(Id):
    eip_address_dict = ec2_client.describe_addresses()
    #List of IP addresses is not empty, so we may have an unassociated IP address?
    eipList = eip_address_dict['Addresses']
    if not eipList:
        eip = allocateEip()
        if eip == 'false':
            return 'false'
    else:
        #There are some elastic IPs floating around, so find if one of the is not associated with an instance
        logger.info("[INFO]: Found some EIPs")
        eip = getUnassociatedAddress(eipList)
        #If the address is blank, then no unassociated addresses were found
        if eip is None:
            #So allocate an elastic ip
            eip = allocateEip()
            if eip == 'false':
                return 'false'

    err = associateAddress(eip['AllocationId'], Id)
    if err == 'false':
        return 'false'
    return  eip

def start_state_function(state_machine_arn, data):
    sfnConnection = boto3.client('stepfunctions')
    input = json.dumps(data)
    if sfnConnection.list_executions(stateMachineArn=state_machine_arn, statusFilter='RUNNING')[
        'executions']:
        logger.info("StateMachine is Running, hence exiting from execution")
    else:
        logger.info("StateMachine is not Running, hence starting StepFunction")
        sfnConnection.start_execution(stateMachineArn=state_machine_arn, input=input)

def terminate(success, asg_message, instanceId):


    if asg_message == None:
        return #this is not via an ASG event, but via CFT custom resource.
    else:
        #log that we"re terminating and why
        if (success == "false"):
            logging.error("[ERROR]: Lambda function reporting failure to AutoScaling with error:\n")
            result = "ABANDON"
        else:
            logger.info("[INFO]: Lambda function reporting success to AutoScaling.")
            result = "CONTINUE"

        #call autoscaling
        asg.complete_lifecycle_action(
            AutoScalingGroupName = asg_message["AutoScalingGroupName"],
            LifecycleHookName = asg_message["LifecycleHookName"],
            LifecycleActionToken = asg_message["LifecycleActionToken"],
            InstanceId = instanceId,
            LifecycleActionResult = result)
        return

def add_eni_lambda_handler(event, context):
    """
    The entry point when this lambda function gets
    invoked.

    .. note:: The primary objective of this lambda funciton
              is to handle life-cycle hooks and to create / delete
              elastic network interfaces to assign / disassociate to / from
              instances.

    :param event: Encodes all the input variables to the lambda function, when
                      the function is invoked.
                      Essentially AWS Lambda uses this parameter to pass in event
                      data to the handler function.
    :param context: AWS Lambda uses this parameter to provide runtime information to your handler.
    :return: None
    """
    global asg_name



    global Namespace
    global SubnetIDNATGW
    global logger
    global Arn

    global debug

    debug = "Yes"

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    event_type = ""

    # Coming here via Sns?
    if ('Records' in event):
        message = json.loads(event['Records'][0]['Sns']['Message'])
        logger.info("[MESSAGE]: {}".format(message))
        if 'LifecycleTransition' in message:
            if (message.get('LifecycleTransition') == "autoscaling:EC2_INSTANCE_LAUNCHING"):
                logger.info("[INFO] Lifecyclehook Launching\n")
                event_type = 'launch'
            elif (message.get('LifecycleTransition') == "autoscaling:EC2_INSTANCE_TERMINATING"):
                logger.info("[INFO] Lifecyclehook Terminating\n")
                event_type = 'terminate'
            else:
                logger.info("[ERROR]/[INFO] One of the other lifeycycle transition messages received\n")
                event_type = 'other'
        elif 'Event' in message:
            if (message.get('Event') == "autoscaling:TEST_NOTIFICATION"):
                logger.info("[INFO]: GOT TEST NOTIFICATION. Do nothing")
                return
            elif (message.get('Event') == "autoscaling:EC2_INSTANCE_LAUNCH"):
                logger.info("[INFO]: GOT launch notification...will get launching event from lifecyclehook")
                # logger.info("[EVENT]: {}".format(event))
                return
            elif (message.get('Event') == "autoscaling:EC2_INSTANCE_TERMINATE"):
                logger.info("[INFO]: GOT terminate notification....will get terminating event from lifecyclehook")
                return
            elif (message.get('Event') == "autoscaling:EC2_INSTANCE_TERMINATE_ERROR"):
                logger.info("[INFO]: GOT a GW terminate error...raise exception for now")
                return
            elif (message.get('Event') == "autoscaling:EC2_INSTANCE_LAUNCH_ERROR"):
                logger.info("[INFO]: GOT a GW launch error...raise exception for now")
                return
    else:
        logger.info("[ERROR]: Something else entirely")
        raise Exception("[ERROR]: Something else entirely")


    # logger.info('got event{}'.format(event))

    strevent = str(event)
    LifecycleHookName = message['LifecycleHookName']
    asg_name = message['AutoScalingGroupName']
    instanceId = message['EC2InstanceId']
    logger.info('instanceId: ' + instanceId)

    if debug == 'Yes':
        logger.setLevel(logging.INFO)
    else:
        logger.setLevel(logging.WARNING)

    stackname = os.environ['StackName']
    region = os.environ['Region']
    lambda_bucket_name = os.environ['lambda_bucket_name']
    state_machine_arn = os.environ['state_machine_arn']
    config_gw_func = os.environ['config_fw_arn']


    if event_type == 'terminate':
        logger.info('PANW EC2 Firewall Instance is terminating')
        # remove_eni(message)
        # Remove instance from firewall db
        logger.info('Remove instance %s from firewall table', str(instanceId))

        fwMgmtIp = retrieve_fw_ip(instanceId)

        done('true', context, message)
        return

    if event_type == 'launch':
        logger.info('PANW EC2 Firewall Instance is launching')
        Arn = event['Records'][0]['EventSubscriptionArn']

        logger.info('LifecycleHookName1: ' + message['LifecycleHookName'])


        logger.info("metadata type is {}".format(type(message['NotificationMetadata'])))
        logger.info('Metadata is:')
        metadata = json.loads(message['NotificationMetadata'])
        for k, v in metadata.items():
            logger.info("key {} value {}".format(k, v))
        mgmt = metadata['MGMT']
        untrust = metadata['UNTRUST']
        trust = metadata['TRUST']
        sgm = metadata['SGM']
        sgu = metadata['SGU']
        sgt = metadata['SGT']
        # SubnetIDNATGW = metadata['SubnetIDNATGW']
        username = metadata['username']
        password = metadata['password']
        logger.info('Mgmt Subnet: ' + mgmt + ' Security-Group: ' + sgm)
        logger.info('Untrust Subnet: ' + untrust + ' Security-Group: ' + sgu)
        logger.info('Trust Subnet: ' + trust + ' Security-Group: ' + sgt)

        while True:
            try:
                interfaces_dict = ec2_client.describe_network_interfaces(
                    Filters=[
                        {
                            "Name": "attachment.instance-id",
                            "Values": [instanceId]
                        },
                        {
                            "Name": "attachment.device-index",
                            "Values": ["0"]
                        }]
                )
            except:
                logger.info("[WARN] Is interface 0 not ready?...Retrying")
                continue
            logger.info("[INFO] Interface 0 ready and set to go")
            break

            # Associate EIP to the first interface
        eniId = (interfaces_dict.get("NetworkInterfaces")[0]).get("NetworkInterfaceId")
        ec2_client.modify_network_interface_attribute(NetworkInterfaceId=eniId, Description={"Value": "GPGateway Mgmt"})
        if eniId == None:
            logger.info("[ERROR] Netowrk Interface ID is None. Should not be!")
            # raise Exception("Network interface ID is none : " inspect.stack()[1][3]);
            abandon(context, message)
            return
        # eniId = interfaces_dict["NetworkInterfaces"][0]["NetworkInterfaceId"]

        err = allocate_and_attach_eip(eniId)
        if err == "false":
            logger.info("[ERROR] allocate and attach failed")
            # raise Exception("[ERROR] allocate and attach failed : " inspect.stack()[1][3]);
            abandon(context, message)
            return
        else:
            logger.info("[INFO] allocate and attach successful")
            fwMgmtIp = err.get("PublicIp")
            if fwMgmtIp == None:
                logger.info("[ERROR]: fwMgmtIp is None")
                abandon(context, message)
                return
            else:
                logger.info("[INFO]: fwMgmtIp is %s", fwMgmtIp)

        list_mgmt = mgmt.split(",")
        list_untrust = untrust.split(",")
        list_trust = trust.split(",")

        # get the az to which the instance belongs
        logger.info('The instance being considered is :' + instanceId)
        response = ec2_client.describe_instances(InstanceIds=[instanceId])
        logger.info('Retrived response{}'.format(response))
        az = ''
        for r in response['Reservations']:
            for i in r['Instances']:
                az = i['Placement']['AvailabilityZone']
                logger.info('The instance belongs to AvailabilityZone :' + az)

                # get the subnets for corresponding az of the instance
        mgmt = check_belongsto_az(list_mgmt, az)
        logger.info("The management subnet for this instance is: " + mgmt)
        untrust = check_belongsto_az(list_untrust, az)
        logger.info("The untrust subnet for this instance is: " + untrust)
        trust = check_belongsto_az(list_trust, az)
        logger.info("The trust subnet for this instance is: " + trust)

        # CreateEni for mgmt interface
        nif = ""
        eniId, err = createEni(untrust, sgm, 1)
        if err == 'false':
            logger.info("Error: Eni creation failed\n")
            abandon(context, message)
            return

        # Wait for the ENI to be 'available'
        untrust_eniId = eniId
        err = waitEniReady(eniId)
        if err == 'false':
            logger.info("ERROR: Failure waiting for ENI to be ready")
            abandon(context, message)
            return

        # Attach the network interface to the instance
        untrust_instanceId = instanceId
        untrust_eniId = eniId
        err = attachEni(instanceId, eniId, 1)
        if err == 'false':
            logger.info("ERROR: Failure attaching ENI to instance for eth1")
            removeEni(eniId)
            abandon(context, message)
            return
        else:
            logger.info("INFO: Success! Attached ENI to instance for eth1")

        err = allocate_and_attach_eip(eniId)
        if err == "false":
            logger.info("[ERROR] allocate and attach failed")
            abandon(context, message)
            return
        else:
            logger.info("[INFO] allocate and attach successful")
            fwUntrustPubIP = err.get("PublicIp")
            if fwUntrustPubIP == None:
                logger.info("[ERROR]: fwUntrustPubIP is None")
                abandon(context, message)
                return
            else:
                logger.info("[INFO]: fwUntrustPubIP is %s", fwUntrustPubIP)

        # CreateEni for Trust Subnet
        nif = ""
        eniId, err = createEni(trust, sgt, 2)
        if err == 'false':
            logger.info("Error: Eni creation failed\n")

        logger.info(nif)
        # Wait for the ENI to be 'available'
        err = waitEniReady(eniId)
        if err == 'false':
            logger.info("ERROR: Failure waiting for ENI to be ready")
            abandon(context, message)
            return

        # Attach the network interface to the instance
        err = attachEni(instanceId, eniId, 2)
        if err == 'false':
            logger.info("ERROR: Failure attaching ENI to instance for eth2")
            removeEni(eniId)
            abandon(context, message)
            return
        else:
            logger.info("INFO: Success! Attached ENI to instance for eth2")

        count_eni("ADD", instanceId)

        # Get mgmt IP
        try:
            response = ec2_client.describe_network_interfaces(NetworkInterfaceIds=[untrust_eniId])
        except Exception as e:
            logger.error("[Describe NI failed in Create CW]: {}".format(e))

        ip = "NO_IP"
        pip = "NO_IP"
        try:
            for i in response['NetworkInterfaces']:
                ip = i['PrivateIpAddress']
                pip = i['PrivateIpAddress']
        except Exception as e:
            logger.error("[FW IP Address in Create CW]: {}".format(e))
            ip = "NO_PrivateIP_ADDR"

        if ip.find("NO_") >= 0:
            logger.error('We failed to get either EIP or Private IP for instance: ' + str(instanceId) + ' IP: ' + ip)
            logger.error('We will not proceed further with this Instance: ' + str(instanceId))

        # Add instance to firewall table
        parameters = {
            'gateway-mgmt-ip': fwMgmtIp,
            'lambda_bucket_name': lambda_bucket_name,
            'event-name': 'gw-launch',
            'gateway-dp-ip': fwUntrustPubIP,
            'instance-id': instanceId,
            'asg_name': asg_name,
            'asg_hookname': LifecycleHookName
        }

        invoke_response = lambda_client.invoke(FunctionName=config_gw_func,
                                               InvocationType="Event", Payload=json.dumps(parameters))
        if invoke_response.get("StatusCode") == 202:
            logger.info("[INFO]: Got OK from invoke lambda functions for launch. exiting...")
            return
        else:
            logger.info("[ERROR]: Something bad happened for launch. invoke_response = {}".format(invoke_response))
            terminate("false", message, instanceId)
            return

        logger.info("sending parameters to step function {}".format(json.dumps(parameters)))

        # start_resp = start_state_function(state_machine_arn, parameters)
        # logger.info("Calling start state function {} ".format(start_resp))

        done('true', context, message)
        return
